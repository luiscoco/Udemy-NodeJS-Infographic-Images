console.log("portable script");
